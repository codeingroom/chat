<?php
$host="localhost";
$username="root";
$password="";
$dbname="test";
$conns=mysqli_connect($host,$username,$password,$dbname)or die("connection Faild..");

?>
