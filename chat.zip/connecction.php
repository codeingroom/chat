<?php
$host="localhost";
$username="root";
$password="";
$dbname="chat";
$conn=mysqli_connect($host,$username,$password,$dbname)or die("connection Faild..");

?>