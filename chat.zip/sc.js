document.getElementById('dd').addEventListener('click',dss);
function dss(e){
	e.preventDefault();
	console.log("this is working");
}