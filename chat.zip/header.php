<style>
*{
	margin:0px;
}
.header{
	margin: 0px;
    background-color: #434646;
    width: 100%;
    height: 10%;
    border: 0px;
    box-shadow: 0px 2px 4px black;
}

</style>
<div class="header"></div>
