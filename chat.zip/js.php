
<script type="text/javascript" src="js/jquery.js"></script>
<script>
console.log("Code Set..");
</script>