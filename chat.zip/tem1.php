<?php
require('tem.php');

?>